class Instruction{

  step(microInstruction, computer){

  }

}

export default Instruction;
