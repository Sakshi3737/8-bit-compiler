import Instruction from "./Instruction.js";

export default Instruction;
